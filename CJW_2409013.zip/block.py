import pygame

class Block:
    def __init__(self, x, y, image_path, width, height):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def move(self, speed):
        self.x -= speed
        self.rect.topleft = (self.x, self.y)

    def draw(self, window, map_x):
        window.blit(self.image, (self.x + map_x, self.y))

    def can_land_on(self, player):
        player_center_x = player.rect.centerx
        player_bottom_y = player.rect.bottom


        if player_center_x >= self.rect.left and player_bottom_y <= self.rect.top:
            return True
        return False
    
    def collide(self, player):
        if player.rect.colliderect(self.rect):
            if self.can_land_on(player):
                player.y = self.rect.top - player.size
                player.jumpspeed = 0
                player.jump_status = False
                return False
            else:
                return True
        return False

class FullBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/SEN/Documents/project/images/FullBlock.png", 100, 100)

class HalfBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/SEN/Documents/project/images/HalfBlock.png", 100, 45)

class FrameBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/SEN/Documents/project/images/FrameBlock.png", 100, 100)
