import pygame
import os

class Obstacle:
    def __init__(self, x, y, image_path, width, height):
        self.x = x
        self.y = y
        base_path = os.path.dirname(__file__) 
        full_image_path = os.path.join(base_path, image_path)  
        self.image = pygame.image.load(full_image_path)
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.mask = pygame.mask.from_surface(self.image)


    def move(self, speed):
        self.x -= speed
        if self.x + self.rect.width < 0:
            self.x = 30000  # 맵 끝에 다시 배치
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)

    def draw(self, window, map_x):
        window.blit(self.image, (self.x + map_x, self.y))

    def collide(self, player):
        return pygame.sprite.collide_mask(self, player)

class SpikeUp(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/SpikeUp.png", 100, 100)

class SpikeDown(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/SpikeDown.png", 100, 100)

class SpikeLeft(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/SpikeLeft.png", 100, 100)

class SpikeRight(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/SpikeRight.png", 100, 100)

class WaveFloor(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/WaveFloor.png", 100, 50)

class LowSpike(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "images/LowSpike.png", 80, 35)
