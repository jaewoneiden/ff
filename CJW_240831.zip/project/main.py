import pygame
import sys
from player import Player
from block import FullBlock
from obstacle import SpikeUp, SpikeDown, SpikeLeft, SpikeRight, WaveFloor, LowSpike
pygame.init()

WIDTH, HEIGHT = 1900, 1000
FLOOR_HEIGHT = 200
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Geometry Dash")

WHITE = (255, 255, 255)
DARKEN_COLOR = (50, 50, 50, 70) 
scroll_speed = 7.5
background_scroll_speed = scroll_speed // 7.5  # 배경 스크롤 속도
game_duration = 30
start_delay = 3
end_delay = 2
frame_rate = 60


background = pygame.image.load("C:/Users/jaewo/Documents/project/images/background.png")
background = pygame.transform.scale(background, (WIDTH, HEIGHT))


floor_line = pygame.image.load("C:/Users/jaewo/Documents/project/images/FloorLine.png")
floor_line = pygame.transform.scale(floor_line, (WIDTH, 10))  # 얇은 선으로 변환


pygame.mixer.music.load("C:/Users/jaewo/Documents/project/images/xStep.ogg")
pygame.mixer.music.play(-1)

clock = pygame.time.Clock()

def create_obstacles():
    obstacles = [
        SpikeUp(2000, HEIGHT - FLOOR_HEIGHT - 100),
        LowSpike(3300, HEIGHT - FLOOR_HEIGHT - 35),
        SpikeUp(3380,HEIGHT - FLOOR_HEIGHT - 100)
    ]
    return obstacles
def create_blocks():
    blocks = [
        FullBlock(5000, HEIGHT - FLOOR_HEIGHT - 200),
        FullBlock(5200, HEIGHT - FLOOR_HEIGHT - 300),
        
    ]
def main():
    player = Player(100, HEIGHT - FLOOR_HEIGHT - 100, 100)
    #block = Block(400, HEIGHT - FLOOR_HEIGHT - 60, 300, 10)
    obstacles = create_obstacles()
    map_x = 0
    background_x = 0

    start_ticks = pygame.time.get_ticks()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.jump()

        player.update()
        #block.move(scroll_speed)
        for obstacle in obstacles:
            obstacle.move(scroll_speed)

        #if block.collide(player):
        #    player.y = block.y - player.size
        #    player.jumpspeed = 0
        #    player.jump_status = False

        #for obstacle in obstacles:
        #    if player.collide(obstacle):
        #        print("Game Over!")
        #        pygame.quit()
        #        sys.exit()

        background_x -= background_scroll_speed
        if background_x <= -WIDTH:
            background_x = 0

        map_x -= scroll_speed

        window.blit(background, (background_x, 0))
        window.blit(background, (background_x + WIDTH, 0))

        window.blit(floor_line, (0, HEIGHT - FLOOR_HEIGHT))

        darken_surface = pygame.Surface((WIDTH, HEIGHT - (HEIGHT - FLOOR_HEIGHT + 10)))
        darken_surface.set_alpha(50)  # 투명도 설정
        darken_surface.fill(DARKEN_COLOR[:3]) 
        window.blit(darken_surface, (0, HEIGHT - FLOOR_HEIGHT + 10))

        player.draw(window)
        #block.draw(window)
        for obstacle in obstacles:
            obstacle.draw(window, map_x)

        pygame.display.update()
        clock.tick(frame_rate)

        elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000
        if elapsed_time >= game_duration + start_delay:
            running = False

    pygame.time.wait(end_delay * 1000)

if __name__ == "__main__":
    main()
