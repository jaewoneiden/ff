import pygame

class Obstacle:
    def __init__(self, x, y, image_path, width, height):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.mask = pygame.mask.from_surface(self.image)

    def move(self, speed):
        self.x -= speed
        if self.x + self.rect.width < 0:
            self.x = 30000  # 맵 끝에 다시 배치
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)

    def draw(self, window, map_x):
        window.blit(self.image, (self.x + map_x, self.y))

    #def collide(self, player):
    #    if self.rect.colliderect(player.rect):
    #        offset_x = self.rect.x - player.rect.x
    #        offset_y = self.rect.y - player.rect.y
    #        if self.mask.overlap(player.mask, (offset_x, offset_y)):
    #            return True
    #    return False

class SpikeUp(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/jaewo/Documents/project/images/SpikeUp.png", 100, 100)

class SpikeDown(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/jaewo/Documents/project/images/SpikeDown.png", 100, 100)

class SpikeLeft(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/jaewo/Documents/project/images/SpikeLeft.png", 100, 100)

class SpikeRight(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/jaewo/Documents/project/images/SpikeRight.png", 100, 100)

class WaveFloor(Obstacle):
    def __init__(self, x, y):
        super().__init__(x, y, "C:/Users/jaewo/Documents/project/images/WaveFloor.png", 100, 50)

class LowSpike(Obstacle):
    def __init__(self,x,y):
        super().__init__(x, y,"C:/Users/jaewo/Documents/project/images/LowSpike.png", 80,35)
