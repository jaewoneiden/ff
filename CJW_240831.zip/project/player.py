import pygame

class Player:
    def __init__(self, x, y, size):
        self.x = x
        self.y = y
        self.size = size
        self.jumpspeed = 0
        self.jump_height = -self.size * 0.2
        self.gravity = 1
        self.jump_status = False
        self.angle = 0
        self.target_angle = 0
        self.rotation_speed = 5
        self.image = pygame.image.load("C:/Users/jaewo/Documents/project/images/Player.png")
        self.image = pygame.transform.scale(self.image, (self.size, self.size))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.mask = pygame.mask.from_surface(self.image)

    def jump(self):
        if not self.jump_status:
            self.jump_status = True
            self.jumpspeed = self.jump_height
            self.target_angle += 180

    def apply_gravity(self):
        self.y += self.jumpspeed
        self.jumpspeed += self.gravity
        if self.y >= 1000 - 200 - self.size:  # HEIGHT - FLOOR_HEIGHT - self.size
            self.y = 1000 - 200 - self.size
            self.jumpspeed = 0
            self.jump_status = False

        self.rect.topleft = (self.x, self.y)


    def rotate(self):
        if self.angle < self.target_angle:
            self.angle += self.rotation_speed
            if self.angle > self.target_angle:
                self.angle = self.target_angle
            self.image = pygame.transform.rotate(pygame.image.load("C:/Users/jaewo/Documents/project/images/Player.png"), self.angle)
            self.image = pygame.transform.scale(self.image, (self.size, self.size))
            self.rect = self.image.get_rect(center=self.rect.center)
            self.mask = pygame.mask.from_surface(self.image)

    def update(self):
        if self.jump_status:
            self.apply_gravity()
        self.rotate()
        self.rect.topleft = (self.x, self.y)

    def draw(self, window):
        window.blit(self.image, self.rect)

    def collide(self, obstacle):
        if pygame.sprite.collide_mask(self, obstacle):
            return True
        return False
