import pygame

class Block:
    def __init__(self, x, y, image_path, width, height):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def move(self, speed):
        self.x -= speed
        self.rect.topleft = (self.x, self.y)

    def draw(self, window):
        window.blit(self.image, self.rect)

    def collide(self, player):
        return player.rect.colliderect(self.rect)

class FullBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, 'FullBlock.png', 100, 100)

class HalfBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, 'HalfBlock.png', 100, 45)

class FrameBlock(Block):
    def __init__(self, x, y):
        super().__init__(x, y, 'FrameBlock.png', 100, 100)
