import pygame
import sys
import os
from player import Player
from block import FullBlock, HalfBlock, FrameBlock
from obstacle import SpikeUp, SpikeDown, SpikeLeft, SpikeRight, WaveFloor, LowSpike
pygame.init()
                


base_path = os.path.dirname(__file__)

WIDTH, HEIGHT = 1800, 1000
FLOOR_HEIGHT = 200
window = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Geometry Dash")

WHITE = (255, 255, 255)
DARKEN_COLOR = (50, 50, 50, 70) 
scroll_speed = 7
background_scroll_speed = scroll_speed // 7  # 배경 스크롤 속도
game_duration = 30
frame_rate = 60
background_path = os.path.join(base_path, "images", "background.png")
floorline_path = os.path.join(base_path, "images", "FloorLine.png")
music_path = os.path.join(base_path, "images", "xStep.ogg")
background = pygame.image.load(background_path)
background = pygame.transform.scale(background, (WIDTH, HEIGHT))


floor_line = pygame.image.load(floorline_path)
floor_line = pygame.transform.scale(floor_line, (WIDTH, 10))  # 얇은 선으로 변환


pygame.mixer.music.load(music_path)
pygame.mixer.music.play(-1)

clock = pygame.time.Clock()

def create_obstacles():
    obstacles = [
        SpikeUp(1800, HEIGHT - FLOOR_HEIGHT - 100),
        LowSpike(3000, HEIGHT - FLOOR_HEIGHT - 35),
        SpikeUp(3080, HEIGHT - FLOOR_HEIGHT - 100),
        SpikeUp(4300, HEIGHT-FLOOR_HEIGHT - 100),
        SpikeUp(4400, HEIGHT - FLOOR_HEIGHT - 100),
        SpikeUp(6400,HEIGHT - FLOOR_HEIGHT - 100),
        SpikeUp(6500, HEIGHT - FLOOR_HEIGHT - 100),
        SpikeUp(8500,HEIGHT - FLOOR_HEIGHT - 200),
        SpikeUp(10000, HEIGHT - FLOOR_HEIGHT - 300),
        SpikeUp(13320, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(13420, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(13520, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(13620, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(14020, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(14120, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(14220, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(14320, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(15320, HEIGHT - FLOOR_HEIGHT - 600),
        SpikeUp(15420, HEIGHT - FLOOR_HEIGHT - 600),
        SpikeUp(15520, HEIGHT - FLOOR_HEIGHT - 600),
        SpikeUp(15620, HEIGHT - FLOOR_HEIGHT - 600),
        SpikeUp(16420, HEIGHT - FLOOR_HEIGHT - 500),
        SpikeUp(16520, HEIGHT - FLOOR_HEIGHT - 300),
    ]
    return obstacles
def create_blocks():
    blocks = [
        FullBlock(4500, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(4920,HEIGHT - FLOOR_HEIGHT - 100),
        FullBlock(4920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(5340,HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(5340,HEIGHT - FLOOR_HEIGHT - 200),
        FullBlock(5340, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(7000, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7100, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7200, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7300, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7400, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7500, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7600, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(7700, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8000, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8100, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8200, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8300, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8400, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8500, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8600, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8700, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8800, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(8900, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9000, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9300, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9300, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9400, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9400, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9500, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9500, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9600, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9600, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9700, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9700, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9800, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9800, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(9900, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(9900, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10000, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10000, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10100, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10100, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10200, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10200, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10300, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10300, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10400, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10400, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10500, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10500, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(10600, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(10600, HEIGHT - FLOOR_HEIGHT - 200),
        HalfBlock(11080, HEIGHT - FLOOR_HEIGHT - 280),
        HalfBlock(11460, HEIGHT - FLOOR_HEIGHT - 320),
        HalfBlock(11840, HEIGHT - FLOOR_HEIGHT - 360),
        HalfBlock(12220, HEIGHT - FLOOR_HEIGHT - 400),
        HalfBlock(12500, HEIGHT - FLOOR_HEIGHT - 440),
        FrameBlock(12720, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(12820, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(12920, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13020, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13120, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13220, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13320, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13420, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13520, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13620, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13720, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13820, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(13920, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14020, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14120, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14220, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14320, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14420, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14520, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14620, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14720, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14820, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(14920, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(12720, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(12820, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(12920, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13020, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13120, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13220, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13320, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13420, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13520, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13620, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13720, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13820, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(13920, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14020, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14120, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14220, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14320, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14420, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14520, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14620, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14720, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14820, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(14920, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(12720, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(12820, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(12920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13020, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13120, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13220, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13320, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13420, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13520, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13620, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13720, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13820, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(13920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14020, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14120, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14220, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14320, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14420, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14520, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14620, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14720, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14820, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(14920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(12720, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(12820, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(12920, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13020, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13120, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13220, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13320, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13420, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13520, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13620, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13720, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13820, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(13920, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14020, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14120, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14220, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14320, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14420, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14520, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14620, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14720, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14820, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(14920, HEIGHT - FLOOR_HEIGHT - 100),
        HalfBlock(13420, HEIGHT - FLOOR_HEIGHT - 540),
        HalfBlock(13520, HEIGHT - FLOOR_HEIGHT - 540),
        HalfBlock(14120, HEIGHT - FLOOR_HEIGHT - 540),
        HalfBlock(14220, HEIGHT - FLOOR_HEIGHT - 540),
        FrameBlock(15020, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15120, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15220, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15320, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15420, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15520, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15620, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15720, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15820, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15920, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(15120, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15220, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15320, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15420, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15520, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15620, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15720, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15820, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(15120, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15220, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15320, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15420, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15520, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15620, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15720, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15820, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(15920, HEIGHT - FLOOR_HEIGHT - 100),
        HalfBlock(15320, HEIGHT - FLOOR_HEIGHT - 500),
        HalfBlock(15420, HEIGHT - FLOOR_HEIGHT - 500),
        HalfBlock(15520, HEIGHT - FLOOR_HEIGHT - 500),
        HalfBlock(15620, HEIGHT - FLOOR_HEIGHT - 500),
        FrameBlock(16020, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(16120, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(16220, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(16320, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(16420, HEIGHT - FLOOR_HEIGHT - 400),
        FrameBlock(16020, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(16120, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(16220, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(16320, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(16420, HEIGHT - FLOOR_HEIGHT - 300),
        FrameBlock(16020, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16120, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16220, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16320, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16420, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16520, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16620, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16720, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16820, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16920, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(17020, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(17120, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(17220, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(17320, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(17420, HEIGHT - FLOOR_HEIGHT - 200),
        FrameBlock(16520, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(16620, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(16720, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(16820, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(16920, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(17020, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(17120, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(17220, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(17320, HEIGHT - FLOOR_HEIGHT - 100),
        FrameBlock(17420, HEIGHT - FLOOR_HEIGHT - 100),

    ]
    return blocks
def main():
    player = Player(100, HEIGHT - FLOOR_HEIGHT - 100, 100)
    #block = Block(400, HEIGHT - FLOOR_HEIGHT - 60, 300, 10)
    obstacles = create_obstacles()
    blocks = create_blocks()
    map_x = 0
    background_x = 0
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.jump()

        player.update()

        for obstacle in obstacles:
            obstacle.move(scroll_speed)
    
        for block in blocks:
            block.move(scroll_speed)
        
        

        #if block.collide(player):
        #    player.y = block.y - player.size
        #    player.jumpspeed = 0
        #    player.jump_status = False
        #for obstacle in obstacles:
        #    if obstacle.collide(player):
        #        print("Game Over!")
        #        pygame.quit()
        #        sys.exit()
        

        #for obstacle in obstacles:
        #    if player.collide(obstacle):
        #        print(f"충돌 감지 장애물 위치:({obstacle.rect.x}, {obstacle.rect.y})")
        #        print(f"플레이어 위치: ({player.rect.x}, {player.rect.y})")
        #        print("Game Over!")
        #        running = False


        background_x -= background_scroll_speed
        if background_x <= -WIDTH:
            background_x = 0

        map_x -= scroll_speed

        window.blit(background, (background_x, 0))
        window.blit(background, (background_x + WIDTH, 0))

        window.blit(floor_line, (0, HEIGHT - FLOOR_HEIGHT))

        darken_surface = pygame.Surface((WIDTH, HEIGHT - (HEIGHT - FLOOR_HEIGHT + 10)))
        darken_surface.set_alpha(50)  # 투명도 설정
        darken_surface.fill(DARKEN_COLOR[:3]) 
        window.blit(darken_surface, (0, HEIGHT - FLOOR_HEIGHT + 10))

        player.draw(window)
        #block.draw(window)
        for obstacle in obstacles:
            obstacle.draw(window, map_x)

        for block in blocks:
            block.draw(window, map_x)
        
        for obstacle in obstacles:
            if player.collide(obstacle):
                print(f"Collision detected with obstacle at ({obstacle.rect.x}, {obstacle.rect.y})")
                print("Game Over!")
                #main()

        for block in blocks:
            if player.collide(block):
                if player.land_on_block(block):
                    player.rect.bottom = block.rect.top
                    player.jumpspeed = 0
                    player.jump_status = False
                else:
                    print("Collision with block")
        
        pygame.display.update()
        clock.tick(frame_rate)
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
